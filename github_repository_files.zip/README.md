# SkillPrep

SkillPrep is a MERN stack-based placement preparation platform designed to help students improve aptitude and technical skills through quizzes, score analysis, and personalized recommendations.

## Features
- Student Authentication
- Quiz Practice
- Score Analysis
- Personalized Recommendations
- Admin Dashboard
- Responsive UI

## Tech Stack
- MongoDB
- Express.js
- React.js
- Node.js
- Tailwind CSS
- Clerk Authentication

## Installation

```bash
git clone <repository-url>
cd project-folder
npm install
npm run dev
```

## Author
Ravi Teja
